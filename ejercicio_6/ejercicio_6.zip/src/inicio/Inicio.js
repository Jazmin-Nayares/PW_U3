import React from 'react'

export default function Inicio() {
  return (
    <div>Inicio</div>
  )
}
